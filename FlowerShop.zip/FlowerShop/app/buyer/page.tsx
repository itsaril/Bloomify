'use client'

import { useSession } from 'next-auth/react'
import { useRouter } from 'next/navigation'
import { useState, useEffect } from 'react'

type Flower = {
  id: string
  name: string
  color: string
  price: number
  imageUrl: string
}

export default function BuyerCatalog() {
  const { data: session, status } = useSession()
  const router = useRouter()
  const [flowers, setFlowers] = useState<Flower[]>([])
  const [filteredFlowers, setFilteredFlowers] = useState<Flower[]>([])
  const [colorFilter, setColorFilter] = useState('')
  const [priceSort, setPriceSort] = useState('')

  useEffect(() => {
    if (status === 'authenticated' && session?.user?.role !== 'BUYER') {
      router.push('/login')
    }
  }, [status, session, router])

  useEffect(() => {
    const fetchFlowers = async () => {
      const response = await fetch('/api/flowers')
      const data = await response.json()
      setFlowers(data.flowers)
      setFilteredFlowers(data.flowers)
    }
    fetchFlowers()
  }, [])

  useEffect(() => {
    let result = [...flowers]
    if (colorFilter) {
      result = result.filter(flower => flower.color === colorFilter)
    }
    if (priceSort === 'asc') {
      result.sort((a, b) => a.price - b.price)
    } else if (priceSort === 'desc') {
      result.sort((a, b) => b.price - a.price)
    }
    setFilteredFlowers(result)
  }, [flowers, colorFilter, priceSort])

  if (status === 'loading') {
    return <div>Loading...</div>
  }

  if (!session) {
    return <div>Access Denied</div>
  }

  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Flower Catalog</h2>
      <div className="mb-4 flex space-x-4">
        <select
          value={colorFilter}
          onChange={(e) => setColorFilter(e.target.value)}
          className="px-2 py-1 border rounded"
        >
          <option value="">All Colors</option>
          <option value="red">Red</option>
          <option value="pink">Pink</option>
          <option value="white">White</option>
          <option value="yellow">Yellow</option>
        </select>
        <select
          value={priceSort}
          onChange={(e) => setPriceSort(e.target.value)}
          className="px-2 py-1 border rounded"
        >
          <option value="">Sort by Price</option>
          <option value="asc">Low to High</option>
          <option value="desc">High to Low</option>
        </select>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredFlowers.map((flower) => (
          <div key={flower.id} className="bg-white p-4 rounded shadow">
            <img src={flower.imageUrl} alt={flower.name} className="w-full h-48 object-cover mb-2 rounded" />
            <h3 className="text-lg font-semibold">{flower.name}</h3>
            <p className="text-gray-600">Color: {flower.color}</p>
            <p className="text-gray-600">Price: ${flower.price.toFixed(2)}</p>
            <button className="mt-2 bg-pink-600 text-white py-1 px-2 rounded hover:bg-pink-700 transition duration-300">
              Add to Cart
            </button>
          </div>
        ))}
      </div>
    </div>
  )
}

